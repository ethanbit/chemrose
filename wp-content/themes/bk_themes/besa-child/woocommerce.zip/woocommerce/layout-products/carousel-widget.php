<?php

wp_enqueue_script( 'slick' );
wp_enqueue_script( 'besa-custom-slick' );

$columns 		= isset($columns) ? $columns : 4;
$show_des 		= isset($show_des) ? $show_des : false;
$countdown 		= isset($countdown) ? $countdown : false;
$flash_sales 	= isset($flash_sales) ? $flash_sales : false;
$end_date 		= isset($end_date) ? $end_date : '';

$countdown_title 		= isset($countdown_title) ? $countdown_title : '';

$rows_count 	= isset($rows) ? $rows : 1;
$auto_type		= ( !empty($auto_type) ) ? $auto_type : 'no';
$loop_type		= ( !empty($loop_type) ) ? $loop_type : 'no';
$autospeed_type	= ( !empty($autospeed_type) ) ? $autospeed_type : 500;


$screen_desktop          	=      isset($screen_desktop) ? $screen_desktop : 4;
$screen_desktopsmall     	=      isset($screen_desktopsmall) ? $screen_desktopsmall : 3;
$screen_tablet           	=      isset($screen_tablet) ? $screen_tablet : 3;
$screen_landscape_mobile    =      isset($screen_landscape_mobile) ? $screen_landscape_mobile : 2;
$screen_mobile           	=      isset($screen_mobile) ? $screen_mobile : 1;

$disable_mobile          	=      isset($disable_mobile) ? $disable_mobile : '';

$data_carousel = besa_tbay_data_carousel($rows, $nav_type, $pagi_type, $loop_type, $auto_type, $autospeed_type, $disable_mobile); 
$responsive_carousel  = besa_tbay_check_data_responsive_carousel($columns, $screen_desktop, $screen_desktopsmall, $screen_tablet, $screen_landscape_mobile, $screen_mobile);

$classes = array('products-grid', 'product');
if( besa_woocommerce_quantity_mode_active() ) {
	$classes[] = 'product-quantity-mode';
}  
?>
<div class="owl-carousel products row-<?php echo esc_attr( $rows_count ); ?>" <?php echo trim($responsive_carousel); ?>  <?php echo trim($data_carousel); ?> >
    <?php while ( $loop->have_posts() ): $loop->the_post(); global $product; ?>
		
		<div class="item">
			<?php 
				$post_object = get_post( $loop->get_id() );
        	?> 
            <div <?php wc_product_class( $classes, $post_object ); ?>>
	            <?php wc_get_template( 'item-product/vertical-v1.php', array('show_des' => $show_des, 'countdown' => $countdown, 'countdown_title' => $countdown_title, 'flash_sales' => $flash_sales, 'end_date' => $end_date ) ); ?>
	        </div>
	
		</div>
		
    <?php endwhile; ?>
</div> 
<?php wp_reset_postdata(); ?>