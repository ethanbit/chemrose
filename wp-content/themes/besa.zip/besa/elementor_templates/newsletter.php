<?php 
/**
 * Templates Name: Elementor
 * Widget: Newsletter
 */
?>

<div <?php echo trim($this->get_render_attribute_string('wrapper')); ?>>
    <?php mc4wp_show_form(); ?>
</div>