<?php 
/**
 * Templates Name: Elementor
 * Widget: Currency
 */
    
    ?>
        <div <?php echo trim($this->get_render_attribute_string('wrapper')); ?>>
            <?php $this->besa_currency(); ?>
        </div>
    <?php

    
?>