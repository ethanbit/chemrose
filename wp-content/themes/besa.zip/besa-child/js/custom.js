jQuery(document).ready(function () {
  var getLogoutLink = logoutUrl;
  jQuery('.nav_logout a').attr('href', getLogoutLink);
});
