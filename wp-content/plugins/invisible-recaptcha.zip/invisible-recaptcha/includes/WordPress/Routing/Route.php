<?php
/**
 * Copyright (c) 2016 Ultra Community (http://www.ultracommunity.com)
 */

namespace InvisibleReCaptcha\MchLib\WordPress\Routing;

class Route
{

//	private $arrRouteData = null;
//	private $arrRouteParams = null;

	public function __construct(array $arrRouteData, array $arrRouteParams)
	{

	}



//	private $routePath = null;
//	private $callBackHook  = null;
//	private $template  = null;


//	public function __construct($routePath, Closure $callBackHook = null, $template = null)
//	{
//		$this->routePath = $routePath;
//		$this->callBackHook = $callBackHook;
//		$this->template = $template;
//	}


//	public function hasCallBackHook()
//	{
//		return isset($this->callBackHook);
//	}
//
//	public function hasTemplate()
//	{
//		return !empty($this->template);
//	}
//
//	public function getRoutePath()
//	{
//		return $this->routePath;
//	}
//
//	public function setRoutePath($routePath)
//	{
//		$this->routePath = $routePath;
//	}
//
//	public function getCallBackHook()
//	{
//		return $this->callBackHook;
//	}
//
////	public function setCallBackHook($callBackHook)
////	{
////		$this->callBackHook = $callBackHook;
////	}
//
//	public function getTemplate()
//	{
//		return $this->template;
//	}
//
//
//	public function setTemplate($template)
//	{
//		$this->template = $template;
//	}
//

}
